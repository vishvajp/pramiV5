import React from 'react'

const BranchRegistrtion = () => {
  return (
    <div>Branch</div>
  )
}

export default BranchRegistrtion;